# Setup 

- To run the program, you will need access to ORACLE database.
- By default we connect to `jdbc:oracle:thin:@castor.cc.binghamton.edu:1521:ACAD111`
- You will have to modify username and password. Default username and passwords will not work.


## Query Setup 

start data.sql
start query.sql


# Execute Java Program

javac -cp /usr/lib/oracle/18.3/client64/lib/ojdbc8.jar Project2.java
java -cp /usr/lib/oracle/18.3/client64/lib/ojdbc8.jar Project2