
set serveroutput on

CREATE SEQUENCE purchases_seq
START WITH 100018
INCREMENT BY 1
CACHE 20;

CREATE SEQUENCE supply_seq
START WITH 1007
INCREMENT BY 1
CACHE 20;

CREATE SEQUENCE sequence_log
START WITH 1
INCREMENT BY 1
CACHE 20;

create or replace package display as
	type rfcursor is ref cursor;
	function f1 -- employees
	return rfcursor;
	function f2 -- customers
	return rfcursor;
	function f3  -- products
	return rfcursor;
	function f4 -- suppliers
	return  rfcursor;
	function f5 -- supply
	return rfcursor;
	function f6 -- purchases
	return rfcursor;
	function f7 -- logs
	return rfcursor;
end;
/
show errors

create or replace package body display as
	function f1
	return rfcursor is
	rf1 rfcursor;
	begin
	open rf1 for 
	select * from employees;
	return rf1;
	end;
	
	function f2
	return rfcursor is
	rf2 rfcursor;
	begin 
	open rf2 for
	select * from customers;
	return rf2;
	end;

	function f3
	return rfcursor is
	rf3 rfcursor;
	begin 
	open rf3 for
	select * from products;
	return rf3;
	end;

	function f4
	return rfcursor is
	rf4 rfcursor;
	begin 
	open rf4 for
	select * from suppliers;
	return rf4;
	end;

	function f5
	return rfcursor is
	rf5 rfcursor;
	begin 
	open rf5 for
	select * from supply;
	return rf5;
	end;

	function f6
	return rfcursor is
	rf6 rfcursor;
	begin 
	open rf6 for
	select * from purchases;
	return rf6;
	end;

	function f7
	return rfcursor is
	rf7 rfcursor;
	begin 
	open rf7 for
	select * from logs;
	return rf7;
	end;
	
end;
/
show errors

CREATE OR REPLACE PROCEDURE report_monthly_sale(v_pid IN products.pid%TYPE)
AS
cursor c1 is
    select pro.pname,pur.pid, 
        SUBSTR(pur.ptime, 4, 3) AS MONTH, 
        SUM(pur.qty) AS QTY,
        SUBSTR(pur.ptime,8,4)as Year, 
        SUM(pur.TOTAL_PRICE) AS SUM_TOTAL_PRICE, 
        (SUM(pur.TOTAL_PRICE)/ SUM(pur.qty)) AS AVG 
    from purchases pur join products pro on pur.pid = pro.pid 
    where pur.pid=v_pid 
    GROUP BY pur.pid, SUBSTR(pur.ptime, 4, 3),pro.pname, SUBSTR(pur.ptime,8,4);
c1_rec c1%rowtype;
begin
	open c1;
	dbms_output.put_line(rpad('PNAME',15)||' '||lpad('PID',4)||' '||rpad('MONTH#',3)||' '||lpad('QTY',4)||' '||lpad('YEAR',4)||' '||lpad('SUM_TOTAL_PRICE',6)||' '||lpad('AVG',6));
	dbms_output.put_line('-----------------------------------------------------');
	loop
		fetch c1 into c1_rec;
		exit when c1%notfound;
		dbms_output.put_line(rpad(to_char(c1_rec.pname),15)||' '||lpad(to_char(c1_rec.pid),4)||' '||rpad(to_char(c1_rec.MONTH),4)||' '||lpad(to_char(c1_rec.QTY),4)||' '||lpad(to_char(c1_rec.YEAR),4)||' '||lpad(to_char(c1_rec.SUM_TOTAL_PRICE),6)||' '||lpad(to_char(c1_rec.AVG),6));
	end loop;
	close c1;

EXCEPTION
   WHEN OTHERS THEN
      dbms_output.put_line( SQLERRM );
end;
/


CREATE SEQUENCE purchases_seq
START WITH 100018
INCREMENT BY 1

CREATE OR REPLACE PACKAGE proj2 IS
PROCEDURE add_products(
    v_PID IN products.PID%TYPE, 
    v_PNAME IN products.PNAME%TYPE, 
    v_QOH IN products.QOH%TYPE,
    v_QOH_THRESHOLD IN products.QOH_THRESHOLD%TYPE, 
    v_ORIGINAL_PRICE IN products.original_price%TYPE,
    v_DISCNT_RATE IN products.DISCNT_RATE % TYPE);

PROCEDURE add_purchases(v_eid IN purchases.eid%TYPE,
    v_pid IN products.pid%TYPE,
    v_cid IN purchases.cid%TYPE,
    v_qty IN purchases.qty%TYPE);
END proj2;
/


CREATE OR REPLACE PACKAGE BODY proj2 IS 

PROCEDURE add_products(
    v_PID IN products.PID%TYPE, 
    v_PNAME IN products.PNAME%TYPE, 
    v_QOH IN products.QOH%TYPE,
    v_QOH_THRESHOLD IN products.QOH_THRESHOLD%TYPE, 
    v_ORIGINAL_PRICE IN products.original_price%TYPE,
    v_DISCNT_RATE IN products.DISCNT_RATE % TYPE)
IS 
BEGIN 
    INSERT INTO products("PID","PNAME","QOH","QOH_THRESHOLD","ORIGINAL_PRICE","DISCNT_RATE") 
            VALUES(v_PID,v_PNAME,v_QOH,v_QOH_THRESHOLD,v_ORIGINAL_PRICE,v_DISCNT_RATE);
COMMIT;
END;


PROCEDURE add_purchases(v_eid IN purchases.eid%TYPE,
    v_pid IN products.pid%TYPE,
    v_cid IN purchases.cid%TYPE,
    v_qty IN purchases.qty%TYPE)
IS 
price products.original_price%TYPE;
BEGIN 
select original_price into price from products where pid=v_pid;
INSERT INTO purchases VALUES(PURCHASES_SEQ.nextval,v_eid,v_pid,v_cid,v_qty,SYSDATE,(v_qty * price));

END;

END proj2;
/



CREATE OR REPLACE TRIGGER insert_purchases
BEFORE INSERT ON PURCHASES
FOR EACH ROW
ENABLE
DECLARE
v_user VARCHAR2(12);
v_date DATE;
begin
  select user, (sysdate) INTO v_user,v_date FROM dual;
  insert into logs (LOG#,WHO,OTIME,TABLE_NAME,OPERATION,KEY_VALUE)
  values (sequence_log.nextval,v_user,v_date,'PURCHASES','INSERT',:NEW.PUR#);
    
end;
/

CREATE OR REPLACE TRIGGER UPDATE_PRODUCTS
BEFORE UPDATE ON PRODUCTS
FOR EACH ROW
ENABLE
DECLARE
v_user VARCHAR2(12);
v_date DATE;
begin
  select user, (sysdate) INTO v_user,v_date FROM dual;
  insert into logs (LOG#,WHO,OTIME,TABLE_NAME,OPERATION,KEY_VALUE)
  values (sequence_log.nextval,v_user,v_date,'PRODUCTS','UPDATE',:NEW.pid);
    
end;
/

CREATE OR REPLACE TRIGGER UPDATE_CUSTOMERS 
BEFORE UPDATE ON CUSTOMERS
FOR EACH ROW
ENABLE
DECLARE
v_user VARCHAR2(12);
v_date DATE;
begin
  select user, (sysdate) INTO v_user,v_date FROM dual;
  insert into logs (LOG#,WHO,OTIME,TABLE_NAME,OPERATION,KEY_VALUE)
  values (sequence_log.nextval,v_user,v_date,'CUSTOMERS','UPDATE',:NEW.cid);
    
end;
/

CREATE OR REPLACE TRIGGER insert_SUPPLY
BEFORE INSERT ON SUPPLY
FOR EACH ROW
ENABLE
DECLARE
v_user VARCHAR2(12);
v_date DATE;
begin
  select user, (sysdate) INTO v_user,v_date FROM dual;
  insert into logs (LOG#,WHO,OTIME,TABLE_NAME,OPERATION,KEY_VALUE)
  values (sequence_log.nextval,v_user,v_date,'SUPPLY','INSERT',:NEW.SUP#);
    
end;
/


create or replace package display as
	type rfcursor is ref cursor;
	function f1 -- employees
	return rfcursor;
	function f2 -- customers
	return rfcursor;
	function f3  -- products
	return rfcursor;
	function f4 -- suppliers
	return  rfcursor;
	function f5 -- supply
	return rfcursor;
	function f6 -- purchases
	return rfcursor;
	function f7 -- logs
	return rfcursor;
end;
/
show errors

create or replace package body display as
	function f1
	return rfcursor is
	rf1 rfcursor;
	begin
	open rf1 for 
	select * from employees;
	return rf1;
	end;
	
	function f2
	return rfcursor is
	rf2 rfcursor;
	begin 
	open rf2 for
	select * from customers;
	return rf2;
	end;

	function f3
	return rfcursor is
	rf3 rfcursor;
	begin 
	open rf3 for
	select * from products;
	return rf3;
	end;

	function f4
	return rfcursor is
	rf4 rfcursor;
	begin 
	open rf4 for
	select * from suppliers;
	return rf4;
	end;

	function f5
	return rfcursor is
	rf5 rfcursor;
	begin 
	open rf5 for
	select * from supply;
	return rf5;
	end;

	function f6
	return rfcursor is
	rf6 rfcursor;
	begin 
	open rf6 for
	select * from purchases;
	return rf6;
	end;

	function f7
	return rfcursor is
	rf7 rfcursor;
	begin 
	open rf7 for
	select * from logs;
	return rf7;
	end;
	
end;
/
show errors

CREATE OR REPLACE PROCEDURE report_monthly_sale(v_pid IN products.pid%TYPE)
AS
cursor c1 is
    select pro.pname,pur.pid, 
        SUBSTR(pur.ptime, 4, 3) AS MONTH, 
        SUM(pur.qty) AS QTY,
        SUBSTR(pur.ptime,8,4)as Year, 
        SUM(pur.TOTAL_PRICE) AS SUM_TOTAL_PRICE, 
        (SUM(pur.TOTAL_PRICE)/ SUM(pur.qty)) AS AVG 
    from purchases pur join products pro on pur.pid = pro.pid 
    where pur.pid=v_pid 
    GROUP BY pur.pid, SUBSTR(pur.ptime, 4, 3),pro.pname, SUBSTR(pur.ptime,8,4);
c1_rec c1%rowtype;
begin
	open c1;
	dbms_output.put_line(rpad('PNAME',15)||' '||lpad('PID',4)||' '||rpad('MONTH#',3)||' '||lpad('QTY',4)||' '||lpad('YEAR',4)||' '||lpad('SUM_TOTAL_PRICE',6)||' '||lpad('AVG',6));
	dbms_output.put_line('-----------------------------------------------------');
	loop
		fetch c1 into c1_rec;
		exit when c1%notfound;
		dbms_output.put_line(rpad(to_char(c1_rec.pname),15)||' '||lpad(to_char(c1_rec.pid),4)||' '||rpad(to_char(c1_rec.MONTH),4)||' '||lpad(to_char(c1_rec.QTY),4)||' '||lpad(to_char(c1_rec.YEAR),4)||' '||lpad(to_char(c1_rec.SUM_TOTAL_PRICE),6)||' '||lpad(to_char(c1_rec.AVG),6));
	end loop;
	close c1;

EXCEPTION
   WHEN OTHERS THEN
      dbms_output.put_line( SQLERRM );
end;
/


CREATE SEQUENCE purchases_seq
START WITH 100018
INCREMENT BY 1

CREATE OR REPLACE PACKAGE proj2 IS
PROCEDURE add_products(
    v_PID IN products.PID%TYPE, 
    v_PNAME IN products.PNAME%TYPE, 
    v_QOH IN products.QOH%TYPE,
    v_QOH_THRESHOLD IN products.QOH_THRESHOLD%TYPE, 
    v_ORIGINAL_PRICE IN products.original_price%TYPE,
    v_DISCNT_RATE IN products.DISCNT_RATE % TYPE);

PROCEDURE add_purchases(v_eid IN purchases.eid%TYPE,
    v_pid IN products.pid%TYPE,
    v_cid IN purchases.cid%TYPE,
    v_qty IN purchases.qty%TYPE);
END proj2;
/


CREATE OR REPLACE PACKAGE BODY proj2 IS 

PROCEDURE add_products(
    v_PID IN products.PID%TYPE, 
    v_PNAME IN products.PNAME%TYPE, 
    v_QOH IN products.QOH%TYPE,
    v_QOH_THRESHOLD IN products.QOH_THRESHOLD%TYPE, 
    v_ORIGINAL_PRICE IN products.original_price%TYPE,
    v_DISCNT_RATE IN products.DISCNT_RATE % TYPE)
IS 
BEGIN 
    INSERT INTO products("PID","PNAME","QOH","QOH_THRESHOLD","ORIGINAL_PRICE","DISCNT_RATE") 
            VALUES(v_PID,v_PNAME,v_QOH,v_QOH_THRESHOLD,v_ORIGINAL_PRICE,v_DISCNT_RATE);
COMMIT;
END;


PROCEDURE add_purchases(v_eid IN purchases.eid%TYPE,
    v_pid IN products.pid%TYPE,
    v_cid IN purchases.cid%TYPE,
    v_qty IN purchases.qty%TYPE)
IS 
price products.original_price%TYPE;
BEGIN 
select original_price into price from products where pid=v_pid;
INSERT INTO purchases VALUES(PURCHASES_SEQ.nextval,v_eid,v_pid,v_cid,v_qty,SYSDATE,(v_qty * price));

END;

END proj2;
/

CREATE SEQUENCE sequence_log
START WITH 1
INCREMENT BY 1
CACHE 20;

CREATE OR REPLACE TRIGGER insert_purchases
BEFORE INSERT ON PURCHASES
FOR EACH ROW
ENABLE
DECLARE
v_user VARCHAR2(12);
v_date DATE;
begin
  select user, (sysdate) INTO v_user,v_date FROM dual;
  insert into logs (LOG#,WHO,OTIME,TABLE_NAME,OPERATION,KEY_VALUE)
  values (sequence_log.nextval,v_user,v_date,'PURCHASES','INSERT',:NEW.PUR#);
    
end;
/

CREATE OR REPLACE TRIGGER UPDATE_PRODUCTS
BEFORE UPDATE ON PRODUCTS
FOR EACH ROW
ENABLE
DECLARE
v_user VARCHAR2(12);
v_date DATE;
begin
  select user, (sysdate) INTO v_user,v_date FROM dual;
  insert into logs (LOG#,WHO,OTIME,TABLE_NAME,OPERATION,KEY_VALUE)
  values (sequence_log.nextval,v_user,v_date,'PRODUCTS','UPDATE',:NEW.pid);
    
end;
/

CREATE OR REPLACE TRIGGER UPDATE_CUSTOMERS 
BEFORE UPDATE ON CUSTOMERS
FOR EACH ROW
ENABLE
DECLARE
v_user VARCHAR2(12);
v_date DATE;
begin
  select user, (sysdate) INTO v_user,v_date FROM dual;
  insert into logs (LOG#,WHO,OTIME,TABLE_NAME,OPERATION,KEY_VALUE)
  values (sequence_log.nextval,v_user,v_date,'CUSTOMERS','UPDATE',:NEW.cid);
    
end;
/

CREATE OR REPLACE TRIGGER insert_SUPPLY
BEFORE INSERT ON SUPPLY
FOR EACH ROW
ENABLE
DECLARE
v_user VARCHAR2(12);
v_date DATE;
begin
  select user, (sysdate) INTO v_user,v_date FROM dual;
  insert into logs (LOG#,WHO,OTIME,TABLE_NAME,OPERATION,KEY_VALUE)
  values (sequence_log.nextval,v_user,v_date,'SUPPLY','INSERT',:NEW.SUP#);
    
end;
/


set serveroutput on
create or replace procedure func3(
pur# in purchases.pur#%type,
 eid in purchases.eid%type, 
 p_id in purchases.pid%type,
  cid in purchases.cid%type, 
  qty in purchases.qty%type,
   ptime in purchases.ptime%type, 
   total_price in purchases.total_price%type)
as
	begin
	declare
		cursor c2 is
			select * from products;
		c2_rec c2%rowtype;
		begin
		open c2;
		loop
			fetch c2 into c2_rec;
			exit when c2%notfound;
			if(c2_rec.pid  = p_id) then
				exit;
			end if;
		end loop;
		close c2;

		if (qty<=c2_rec.qoh) then
		begin
			insert into purchases values(pur#,eid, p_id, cid, qty, ptime, total_price);
		end;

		else
		begin
			dbms_output.put_line('Insufficient stock.');
			dbms_output.put_line('Purchase Rejected!!');
			
		end;
		end if;


		end;
	end;
	/
	show errors

set serveroutput on
create or replace trigger tr_supply_copy2
	after insert on purchases
	for each row
	enable 
	declare
	arg_pid char(4);
	arg_qoh_threshold number(4);
	arg_qoh number(5);
	temp number(5);
	temp2 char(4);
	temp22 number(4);
	temp3 date;
	temp_sid char(2);
	begin 
	dbms_output.put_line('Need more supply of: ');
	dbms_output.put_line(:new.pid);
	select qoh_threshold into arg_qoh_threshold 
	from products 
	where pid = :new.pid;

	select qoh into arg_qoh
	from products
	where pid = :new.pid;

		if(arg_qoh < arg_qoh_threshold) then
		insert into supply values(supply_seq.nextval,
			:new.pid, 's1',sysdate, 
			(arg_qoh_threshold + 5));
		dbms_output.put_line('Inserted into supply!');

		select qoh into temp 
		from products 
		where pid = :new.pid;

		dbms_output.put_line('New qoh is');
		dbms_output.put_line(temp);
		dbms_output.put_line('for ');
		dbms_output.put_line(:new.pid);
		end if;

		-- end of if

		select visits_made into temp22
		from customers
		where cid = :new.cid;

		dbms_output.put_line('Cid id ');
		dbms_output.put_line(:new.cid);


		update customers
		set visits_made = temp22 + 0001
		where cid = :new.cid;

		update customers
			set last_visit_date = :new.ptime
			where cid = :new.cid;

	end;
	/
	show errors



-- insert into purchases if qty <= qoh (q6)
set serveroutput on
create  or replace package query_7_copy2 as
	procedure p1(pur# in purchases.pur#%type, eid in purchases.eid%type, p_id in purchases.pid%type, cid in purchases.cid%type, qty in purchases.qty%type, ptime in purchases.ptime%type, total_price in purchases.total_price%type);
end query_7_copy2;
/
show errors
create or replace package body query_7_copy2 as

	procedure p1(pur# in purchases.pur#%type, eid in purchases.eid%type, p_id in purchases.pid%type, cid in purchases.cid%type, qty in purchases.qty%type, ptime in purchases.ptime%type, total_price in purchases.total_price%type)
	is
	begin -- begin procedure
	declare
		cursor c2 is
			select * from products;
		c2_rec c2%rowtype;
		new_pid products.pid%type;
		new_qoh products.qoh%type;
		new_qoh_threshold products.qoh_threshold%type;
		begin -- open cursor code
		open c2;
			loop
				fetch c2 into c2_rec;
				exit when c2%notfound;
				if(c2_rec.pid = p_id) then
					begin
						new_pid := c2_rec.pid;
						--global_pid := c2_rec.pid;
						new_qoh := c2_rec.qoh;
						--global_qoh := c2_rec.qoh;
						new_qoh_threshold := c2_rec.qoh_threshold;
						--global_qoh_threshold := c2_rec.qoh_threshold;
						exit;
					end;
				end if;
			end loop;
			
		close c2;
		--end; -- close cursor code
		if (qty<= /*new_qoh*/c2_rec.qoh) then
			begin -- * 
				insert into purchases values(pur#,eid, p_id, cid, qty, ptime, total_price);
				update products 
					set products.qoh = (c2_rec.qoh - qty)  
					where (pid = p_id);
				select products.qoh  into new_qoh
					from products
					where pid = p_id;
				dbms_output.put_line('New qoh is ');
				dbms_output.put_line(new_qoh);
				if(new_qoh < new_qoh_threshold) then
					begin -- * *
						dbms_output.put_line('Current qoh below threshold, need more supply of');
						dbms_output.put_line(c2_rec.pname);
					end; -- * of line 53
				end if; -- of line 52
			end;
		else
			begin -- ^
				dbms_output.put_line('Insufficient stock.');
				dbms_output.put_line('Purchase Rejected!!');
				raise_application_error(-20080,'Insufficient stock. Purchase Rejected!!');
				exception when others then
				dbms_output.put_line(dbms_utility.format_error_stack);
			end; --  ^ of line 74
		end if;
		end; -- close cursor code
	end p1; -- end procedure p1
	end query_7_copy2; -- package body end
	/
	show errors





