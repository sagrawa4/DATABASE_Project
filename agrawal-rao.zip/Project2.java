import java.sql.*;
import oracle.jdbc.*;
import java.math.*;
import java.io.*;
import java.awt.*;
import oracle.jdbc.pool.OracleDataSource;
import java.util.Scanner;

public class Project2 
{
    public static String URL = "jdbc:oracle:thin:@castor.cc.binghamton.edu:1521:ACAD111";
    public static String USERNAME = "admin";
    public static String PASSWORD = "password";

    static void Insert()
    {
        // Input table name from keyboard.
        try
        {
            BufferedReader  readKeyBoard; 
            String          table_name;
            readKeyBoard = new BufferedReader(new InputStreamReader(System.in)); 
            System.out.println("Please Enter Table Name to Insert: ");
            table_name = readKeyBoard.readLine();
            InsertTableRow(table_name);
        }
        catch (Exception e) 
        {
            System.out.println (e);
            System.out.println ("\nError, Please Try Again With Valid Table Name!\n");
        }
    }

    static void InsertTableRow(String table_name)
    {
        try
        {
            //Connection to Oracle server
            OracleDataSource ds = new oracle.jdbc.pool.OracleDataSource();
            ds.setURL(URL);
            Connection conn = ds.getConnection(USERNAME, PASSWORD);
            CallableStatement cs;
            Scanner in = new Scanner(System.in);

            switch (table_name) 
            {
                case "products":
                    String pid, pname, qoh, qoh_threshold, original_price, discnt_rate;
                    
                    System.out.println("Enter Product ID : ");
                    pid = in.nextLine();
                    
                    System.out.println("Enter Product Name : ");
                    pname = in.nextLine();

                    System.out.println("Enter Product Quantity in Hand: ");
                    qoh = in.nextLine();

                    System.out.println("Enter Product Quantity in Hand Threashold: ");
                    qoh_threshold = in.nextLine();

                    System.out.println("Enter Product Original Price: ");
                    original_price = in.nextLine();

                    System.out.println("Enter Product Discount Rate: ");
                    discnt_rate = in.nextLine();
                    
                    cs = conn.prepareCall("{ call proj2.add_products(:1,:2,:3,:4,:5,:6)}");
                    cs.setString(1, pid);
                    cs.setString(2, pname);
                    cs.setString(3, qoh);
                    cs.setString(4, qoh_threshold);
                    cs.setString(5, original_price);
                    cs.setString(6, discnt_rate);

                    
                    break;
                case "purchases":
                    
                    String eid, p_pid, cid, qty;

                    System.out.println("Enter Employee ID : ");
                    eid = in.nextLine();
                    
                    System.out.println("Enter Product ID : ");
                    p_pid = in.nextLine();

                    System.out.println("Enter Customer ID : ");
                    cid = in.nextLine();

                    System.out.println("Enter Quantity: ");
                    qty = in.nextLine();
                    
                    cs = conn.prepareCall("{ call proj2.add_purchases(:1,:2,:3,:4)}");
                    cs.setString(1, eid);
                    cs.setString(2, p_pid);
                    cs.setString(3, cid);
                    cs.setString(4, qty);

                    break;
                default:
                    throw new IllegalArgumentException("Insert for this table is not supported: " + table_name);
            }

            cs.executeQuery();

            System.out.println("Successfully inserted!");
            
            cs.close();
            conn.close();
        } 
        catch (SQLException ex) 
        { 
            System.out.println("\n*** SQLException caught ***\n" + ex.getMessage());
            System.out.println(ex);
        }
        catch (Exception e) 
        {
            System.out.println("\n*** other Exception caught ***\n");
            System.out.println(e);
        }
    }


    static void Display()
    {
        // Input table name from keyboard.
        try
        {
            BufferedReader  readKeyBoard; 
            String          table_name;
            readKeyBoard = new BufferedReader(new InputStreamReader(System.in)); 
            System.out.println("Please Enter Table Name to Display: ");
            table_name = readKeyBoard.readLine();
            DisplayTable(table_name);
        }
        catch (Exception e) 
        {
            System.out.println (e);
            System.out.println ("\nError, Please Try Again With Valid Table Name!\n");
        }
    }

    static void DisplayTable(String table_name)
    {
        System.out.println("Displaying table: " + table_name + "\n");
        switch (table_name) 
        {
            case "employees":
                DisplayTablesRows("f1");
                break;
            case "customers":
                DisplayTablesRows("f2");
                break;
            case "products":
                DisplayTablesRows("f3");
                break;
            case "suppliers":
                DisplayTablesRows("f4");
                break;
            case "supply":
                DisplayTablesRows("f5");
                break;
            case "purchases":
                DisplayTablesRows("f6");
                break;
            case "logs":
                DisplayTablesRows("f7");
                break;
            default:
                throw new IllegalArgumentException("Invalid Table Name: " + table_name);
        }
        System.out.println("");
    }

    static void DisplayTablesRows(String sql_function_name)
    {
        try
        {
            //Connection to Oracle server
            OracleDataSource ds = new oracle.jdbc.pool.OracleDataSource();
            ds.setURL(URL);
            Connection conn = ds.getConnection(USERNAME, PASSWORD);

            //Prepare to call stored procedure:
            String statment_with_sql_function_name = String.format("begin ? := display.%s(); end;", sql_function_name);
            CallableStatement cs = conn.prepareCall(statment_with_sql_function_name);
            
            //register the out parameter (the first parameter)
            cs.registerOutParameter(1, OracleTypes.CURSOR);
            
            // execute and retrieve the result set
            cs.execute();
            ResultSet rs = (ResultSet)cs.getObject(1);

            switch (sql_function_name) 
                {
                    case "f1":
                        System.out.println("eid" + "\t" + "ename" + "\t" + "telephone#");
                        System.out.println("---" + "\t" + "----" + "\t" + "----");
                        break;
                    case "f2":
                        System.out.println("cid" + "\t" + "cname" + "\t" + "telephone#" + "\t" + "visits_made" + "\t" + "last_visit_date");
                        System.out.println("---" + "\t" + "---" + "\t" + "---" + "\t" + "---" + "\t" + "---");
                        break;
                    case "f3":
                        System.out.println("pid" + "\t" + "pname" + "\t" + "qoh" + "\t" + "qoh_threshold" + "\t" + "original_price" + "\t" + "discnt_rate");
                        System.out.println("---" + "\t" + "---" + "\t" + "---" + "\t" + "---" + "\t" + "---" + "\t" + "---");
                        break;
                    case "f4":
                        System.out.println("sid" + "\t" + "sname" + "\t" + "city" + "\t" + "telephone#");
                        System.out.println("---" + "\t" + "---" + "\t" + "---" + "\t" + "---");
                        break;
                    case "f5":
                        System.out.println("sup#" + "\t" + "pid" + "\t" + "sid" + "\t" + "sdate" + "\t" + "quantity");
                        System.out.println("---" + "\t" + "---" + "\t" + "---" + "\t" + "---" + "\t" + "---");
                        break;
                    case "f6":
                        System.out.println("pur#" + "\t" + "eid" + "\t" + "pid" + "\t" + "cid" + "\t" + "qty" + "\t" + "ptime" + "\t" + "total_price");
                        System.out.println("---" + "\t" + "---" + "\t" + "---" + "\t" + "---" + "\t" + "---" + "\t" + "---" + "\t" + "---");
                        break;
                    case "f7":
                        System.out.println("log#" + "\t" + "who" + "\t" + "otime" + "\t" + "table_name" + "\t" + "operation" + "\t" + "key_value");
                        System.out.println("---" + "\t" + "---" + "\t" + "---" + "\t" + "---" + "\t" + "---" + "\t" + "---");
                        break;
                    default:
                        throw new IllegalArgumentException("Cannot display row for table as invalid table name: " + sql_function_name);
                }

            // print the results
            while (rs.next()) 
            {
                switch (sql_function_name) 
                {
                    case "f1":
                        System.out.println(rs.getString(1) + "\t" + rs.getString(2) + "\t" + rs.getString(3));
                        break;
                    case "f2":
                        System.out.println(rs.getString(1) + "\t" + rs.getString(2) + "\t" + rs.getString(3) + "\t" + rs.getString(4) + "\t" + rs.getString(5));
                        break;
                    case "f3":
                        System.out.println(rs.getString(1) + "\t" + rs.getString(2) + "\t" + rs.getString(3) + "\t" + rs.getString(4) + "\t" + rs.getString(5) + "\t" + rs.getString(6));
                        break;
                    case "f4":
                        System.out.println(rs.getString(1) + "\t" + rs.getString(2) + "\t" + rs.getString(3) + "\t" + rs.getString(4));
                        break;
                    case "f5":
                        System.out.println(rs.getString(1) + "\t" + rs.getString(2) + "\t" + rs.getString(3) + "\t" + rs.getString(4) + "\t" + rs.getString(5));
                        break;
                    case "f6":
                        System.out.println(rs.getString(1) + "\t" + rs.getString(2) + "\t" + rs.getString(3) + "\t" + rs.getString(4) + "\t" + rs.getString(5) + "\t" + rs.getString(6) + "\t" + rs.getString(7));
                        break;
                    case "f7":
                        System.out.println(rs.getString(1) + "\t" + rs.getString(2) + "\t" + rs.getString(3) + "\t" + rs.getString(4) + "\t" + rs.getString(5) + "\t" + rs.getString(6));
                        break;
                    default:
                        throw new IllegalArgumentException("Cannot display row for table as invalid table name: " + sql_function_name);
                }
            }

            //close the result set, statement, and the connection
            cs.close();
            conn.close();
        } 
        catch (SQLException ex) 
        { 
            System.out.println ("\n*** SQLException caught ***\n" + ex.getMessage());
            System.out.println (ex);
        }
        catch (Exception e) 
        {
            System.out.println ("\n*** other Exception caught ***\n");
            System.out.println (e);
        }
    }

    public static void main (String args []) throws SQLException 
    {
        while(true)
        {
            try
            {
                BufferedReader  readKeyBoard; 
                String          select_option;
                readKeyBoard = new BufferedReader(new InputStreamReader(System.in)); 
                System.out.println("Enter option number :");
                System.out.println("1. Display Table");
                System.out.println("2. Insert into Table");
                System.out.println("3. Exit");
                select_option = readKeyBoard.readLine();
                
                switch (select_option) 
                {
                    case "1":
                        Display();
                        break;   
                    case "2":
                        Insert();
                        break;
                    case "3":
                        return;
                    default:
                        System.out.println("Invalid Option, Please Select from above.");
                }
            }
            catch (Exception e) 
            {
                System.out.println ("\n*** other Exception caught ***\n");
                System.out.println (e);
            }       
        }
    }
} 

