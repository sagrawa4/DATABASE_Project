
CREATE SEQUENCE purchases_seq
START WITH 100018
INCREMENT BY 1

CREATE OR REPLACE PACKAGE proj2 IS
PROCEDURE add_products(
    v_PID IN products.PID%TYPE, 
    v_PNAME IN products.PNAME%TYPE, 
    v_QOH IN products.QOH%TYPE,
    v_QOH_THRESHOLD IN products.QOH_THRESHOLD%TYPE, 
    v_ORIGINAL_PRICE IN products.original_price%TYPE,
    v_DISCNT_RATE IN products.DISCNT_RATE % TYPE);

PROCEDURE add_purchases(v_eid IN purchases.eid%TYPE,
    v_pid IN products.pid%TYPE,
    v_cid IN purchases.cid%TYPE,
    v_qty IN purchases.qty%TYPE);
END proj2;
/


CREATE OR REPLACE PACKAGE BODY proj2 IS 

PROCEDURE add_products(
    v_PID IN products.PID%TYPE, 
    v_PNAME IN products.PNAME%TYPE, 
    v_QOH IN products.QOH%TYPE,
    v_QOH_THRESHOLD IN products.QOH_THRESHOLD%TYPE, 
    v_ORIGINAL_PRICE IN products.original_price%TYPE,
    v_DISCNT_RATE IN products.DISCNT_RATE % TYPE)
IS 
BEGIN 
    INSERT INTO products("PID","PNAME","QOH","QOH_THRESHOLD","ORIGINAL_PRICE","DISCNT_RATE") 
            VALUES(v_PID,v_PNAME,v_QOH,v_QOH_THRESHOLD,v_ORIGINAL_PRICE,v_DISCNT_RATE);
COMMIT;
END;


PROCEDURE add_purchases(v_eid IN purchases.eid%TYPE,
    v_pid IN products.pid%TYPE,
    v_cid IN purchases.cid%TYPE,
    v_qty IN purchases.qty%TYPE)
IS 
price products.original_price%TYPE;
BEGIN 
select original_price into price from products where pid=v_pid;
INSERT INTO purchases VALUES(PURCHASES_SEQ.nextval,v_eid,v_pid,v_cid,v_qty,SYSDATE,(v_qty * price));

END;

END proj2;
/



