CREATE SEQUENCE sequence_log
START WITH 1
INCREMENT BY 1
CACHE 20;

CREATE OR REPLACE TRIGGER insert_purchases
BEFORE INSERT ON PURCHASES
FOR EACH ROW
ENABLE
DECLARE
v_user VARCHAR2(12);
v_date DATE;
begin
  select user, (sysdate) INTO v_user,v_date FROM dual;
  insert into logs (LOG#,WHO,OTIME,TABLE_NAME,OPERATION,KEY_VALUE)
  values (sequence_log.nextval,v_user,v_date,'PURCHASES','INSERT',:NEW.PUR#);
    
end;
/

CREATE OR REPLACE TRIGGER UPDATE_PRODUCTS
BEFORE UPDATE ON PRODUCTS
FOR EACH ROW
ENABLE
DECLARE
v_user VARCHAR2(12);
v_date DATE;
begin
  select user, (sysdate) INTO v_user,v_date FROM dual;
  insert into logs (LOG#,WHO,OTIME,TABLE_NAME,OPERATION,KEY_VALUE)
  values (sequence_log.nextval,v_user,v_date,'PRODUCTS','UPDATE',:NEW.pid);
    
end;
/

CREATE OR REPLACE TRIGGER UPDATE_CUSTOMERS 
BEFORE UPDATE ON CUSTOMERS
FOR EACH ROW
ENABLE
DECLARE
v_user VARCHAR2(12);
v_date DATE;
begin
  select user, (sysdate) INTO v_user,v_date FROM dual;
  insert into logs (LOG#,WHO,OTIME,TABLE_NAME,OPERATION,KEY_VALUE)
  values (sequence_log.nextval,v_user,v_date,'CUSTOMERS','UPDATE',:NEW.cid);
    
end;
/

CREATE OR REPLACE TRIGGER insert_SUPPLY
BEFORE INSERT ON SUPPLY
FOR EACH ROW
ENABLE
DECLARE
v_user VARCHAR2(12);
v_date DATE;
begin
  select user, (sysdate) INTO v_user,v_date FROM dual;
  insert into logs (LOG#,WHO,OTIME,TABLE_NAME,OPERATION,KEY_VALUE)
  values (sequence_log.nextval,v_user,v_date,'SUPPLY','INSERT',:NEW.SUP#);
    
end;
/

