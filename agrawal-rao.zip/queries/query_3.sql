CREATE OR REPLACE PROCEDURE report_monthly_sale(v_pid IN products.pid%TYPE)
AS
cursor c1 is
    select pro.pname,pur.pid, 
        SUBSTR(pur.ptime, 4, 3) AS MONTH, 
        SUM(pur.qty) AS QTY,
        SUBSTR(pur.ptime,8,4)as Year, 
        SUM(pur.TOTAL_PRICE) AS SUM_TOTAL_PRICE, 
        (SUM(pur.TOTAL_PRICE)/ SUM(pur.qty)) AS AVG 
    from purchases pur join products pro on pur.pid = pro.pid 
    where pur.pid=v_pid 
    GROUP BY pur.pid, SUBSTR(pur.ptime, 4, 3),pro.pname, SUBSTR(pur.ptime,8,4);
c1_rec c1%rowtype;
begin
	open c1;
	dbms_output.put_line(rpad('PNAME',15)||' '||lpad('PID',4)||' '||rpad('MONTH#',3)||' '||lpad('QTY',4)||' '||lpad('YEAR',4)||' '||lpad('SUM_TOTAL_PRICE',6)||' '||lpad('AVG',6));
	dbms_output.put_line('-----------------------------------------------------');
	loop
		fetch c1 into c1_rec;
		exit when c1%notfound;
		dbms_output.put_line(rpad(to_char(c1_rec.pname),15)||' '||lpad(to_char(c1_rec.pid),4)||' '||rpad(to_char(c1_rec.MONTH),4)||' '||lpad(to_char(c1_rec.QTY),4)||' '||lpad(to_char(c1_rec.YEAR),4)||' '||lpad(to_char(c1_rec.SUM_TOTAL_PRICE),6)||' '||lpad(to_char(c1_rec.AVG),6));
	end loop;
	close c1;

EXCEPTION
   WHEN OTHERS THEN
      dbms_output.put_line( SQLERRM );
end;
/
