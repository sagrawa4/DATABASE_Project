
set serveroutput on
create or replace procedure func3(
pur# in purchases.pur#%type,
 eid in purchases.eid%type, 
 p_id in purchases.pid%type,
  cid in purchases.cid%type, 
  qty in purchases.qty%type,
   ptime in purchases.ptime%type, 
   total_price in purchases.total_price%type)
as
	begin
	declare
		cursor c2 is
			select * from products;
		c2_rec c2%rowtype;
		begin
		open c2;
		loop
			fetch c2 into c2_rec;
			exit when c2%notfound;
			if(c2_rec.pid = p_id) then
				exit;
			end if;
		end loop;
		close c2;

		if (qty<=c2_rec.qoh) then
		begin
			insert into purchases values(pur#,eid, p_id, cid, qty, ptime, total_price);
			--update products set c2_rec.qoh := (c2_rec.qoh - qty)  where c2_rec.pid = p_id;
		end;
		else
		begin
			dbms_output.put_line('Insufficient stock.');
			dbms_output.put_line('Purchase Rejected!!');
			raise_application_error(-20080,'Insufficient stock. Purchase Rejected!!');
			exception when others then
			dbms_output.put_line(dbms_utility.format_error_stack);
		end;
		end if;
		end;
	end;
	/
	show errors


set serveroutput on
create or replace trigger tr_supply_copy2
	after insert on purchases
	for each row
	enable 
	declare
	arg_pid char(4);
	arg_qoh_threshold number(4);
	arg_qoh number(5);
	temp number(5);
	temp2 char(4);
	temp22 number(4);
	temp3 date;
	temp_sid char(2);
	temp_qoh_after_supply number(5);
	begin 

	update products
		set qoh = qoh - :new.qty
		where pid = :new.pid;

	select qoh_threshold into arg_qoh_threshold 
	from products 
	where pid = :new.pid;

	select qoh into arg_qoh
	from products
	where pid = :new.pid;

	select sid into temp_sid
	from supply
	where pid = :new.pid and rownum=1
	order by sup# asc;

	dbms_output.put_line('In trigger, Value of qoh now is');
	dbms_output.put_line(arg_qoh);
	dbms_output.put_line('In trigger, Value of qoh_threshold now is');
	dbms_output.put_line(arg_qoh_threshold);


-- start of if

	if(arg_qoh < arg_qoh_threshold) then

	-- insert into supply

	dbms_output.put_line('Need more supply of: ');
	dbms_output.put_line(:new.pid);
		insert into supply values(supply_seq.nextval,
			:new.pid, temp_sid,sysdate, 
			(arg_qoh_threshold + 5));
		dbms_output.put_line('Inserted into supply!');

		-- store new qoh in a temp variable
		select (qoh_threshold + 5) into temp_qoh_after_supply
		from  products
		where  pid = :new.pid;

		-- update the product with the new qoh
		update products
			set qoh = temp_qoh_after_supply
			where pid = :new.pid;

		dbms_output.put_line('In the trigger, after updating products');
		dbms_output.put_line('The new qoh is');
		dbms_output.put_line(temp_qoh_after_supply); 

	end if;

		-- end of if

		
		select visits_made into temp22
		from customers
		where cid = :new.cid;

		-- updating customer info of visits_made
		update customers
		set visits_made = temp22 + 0001
		where cid = :new.cid;

		-- updating customer info of last_visit_made
		update customers
			set last_visit_date = :new.ptime
			where cid = :new.cid;

	end;
	/
	show errors








-- insert into purchases if qty <= qoh (q6)
set serveroutput on
create  or replace package query_7_copy2 as
	procedure p1(pur# in purchases.pur#%type, eid in purchases.eid%type, p_id in purchases.pid%type, cid in purchases.cid%type, qty in purchases.qty%type, ptime in purchases.ptime%type, total_price in purchases.total_price%type);
end query_7_copy2;
/
show errors
create or replace package body query_7_copy2 as

	procedure p1(pur# in purchases.pur#%type, eid in purchases.eid%type, p_id in purchases.pid%type, cid in purchases.cid%type, qty in purchases.qty%type, ptime in purchases.ptime%type, total_price in purchases.total_price%type)
	is
	begin -- begin procedure
	declare
		cursor c2 is
			select * from products;
		c2_rec c2%rowtype;
		new_pid products.pid%type;
		new_qoh products.qoh%type;
		new_qoh_threshold products.qoh_threshold%type;
		begin -- open cursor code
		open c2;
			loop
				fetch c2 into c2_rec;
				exit when c2%notfound;
				if(c2_rec.pid = p_id) then
					begin
						new_pid := c2_rec.pid;
						new_qoh := c2_rec.qoh;
						new_qoh_threshold := c2_rec.qoh_threshold;
						exit;
					end;
				end if;
			end loop;
			
		close c2;
		--end; -- close cursor code


		-- if quantity to be purchased is less than the available qoh then do this
		if (qty<= /*new_qoh*/c2_rec.qoh) then
			begin -- * 
				insert into purchases values(pur#,eid, p_id, cid, qty, ptime, total_price);
				update products 
					set products.qoh = (c2_rec.qoh - qty)  
					where (pid = p_id);
				select products.qoh  into new_qoh
					from products
					where pid = p_id;
				
			end;

			-- quantity to be purchased is more than the available qoh then do this
		else
			begin 
				dbms_output.put_line('Insufficient stock.');
				dbms_output.put_line('Purchase Rejected!!');
				raise_application_error(-20080,'Insufficient stock. Purchase Rejected!!');
				exception when others then
				dbms_output.put_line(dbms_utility.format_error_stack);
			end; 
		end if;
		end; -- close cursor code
	end p1; -- end procedure p1
	end query_7_copy2; -- package body end
	/
	show errors
