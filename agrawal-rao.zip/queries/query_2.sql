set serveroutput on
create or replace package display as
	type rfcursor is ref cursor;
	function f1 -- employees
	return rfcursor;
	function f2 -- customers
	return rfcursor;
	function f3  -- products
	return rfcursor;
	function f4 -- suppliers
	return  rfcursor;
	function f5 -- supply
	return rfcursor;
	function f6 -- purchases
	return rfcursor;
	function f7 -- logs
	return rfcursor;
end;
/
show errors

create or replace package body display as
	function f1
	return rfcursor is
	rf1 rfcursor;
	begin
	open rf1 for 
	select * from employees;
	return rf1;
	end;
	
	function f2
	return rfcursor is
	rf2 rfcursor;
	begin 
	open rf2 for
	select * from customers;
	return rf2;
	end;

	function f3
	return rfcursor is
	rf3 rfcursor;
	begin 
	open rf3 for
	select * from products;
	return rf3;
	end;

	function f4
	return rfcursor is
	rf4 rfcursor;
	begin 
	open rf4 for
	select * from suppliers;
	return rf4;
	end;

	function f5
	return rfcursor is
	rf5 rfcursor;
	begin 
	open rf5 for
	select * from supply;
	return rf5;
	end;

	function f6
	return rfcursor is
	rf6 rfcursor;
	begin 
	open rf6 for
	select * from purchases;
	return rf6;
	end;

	function f7
	return rfcursor is
	rf7 rfcursor;
	begin 
	open rf7 for
	select * from logs;
	return rf7;
	end;
	
end;
/
show errors


