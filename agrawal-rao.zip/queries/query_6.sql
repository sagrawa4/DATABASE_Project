
set serveroutput on
create or replace procedure func3(
pur# in purchases.pur#%type,
 eid in purchases.eid%type, 
 p_id in purchases.pid%type,
  cid in purchases.cid%type, 
  qty in purchases.qty%type,
   ptime in purchases.ptime%type, 
   total_price in purchases.total_price%type)
as
	begin
	declare
		cursor c2 is
			select * from products;
		c2_rec c2%rowtype;
		begin
		open c2;
		loop
			fetch c2 into c2_rec;
			exit when c2%notfound;
			if(c2_rec.pid  = p_id) then
				exit;
			end if;
		end loop;
		close c2;

		if (qty<=c2_rec.qoh) then
		begin
			insert into purchases values(pur#,eid, p_id, cid, qty, ptime, total_price);
		end;

		else
		begin
			dbms_output.put_line('Insufficient stock.');
			dbms_output.put_line('Purchase Rejected!!');
			
		end;
		end if;


		end;
	end;
	/
	show errors
